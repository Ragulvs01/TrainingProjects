package com;

public class CircularLinkedList {
	static class Node 
	{ 
		int data; 
    	Node next; 
        Node(int a) 
    		{ 
        	  data = a; 
            	next = null; 
    		} 
     }
     Node head; 
      CircularLinkedList()   
      { 
       head = null; 
       } 
       void sortedInsert(Node r) 
	 { 
        Node current = head; 
         if (current == null) 
    		{ 
        		r.next = r; 
        		head = r; 
		   } 
        else if (current.data >= r.data) 
    		{ 
          while (current.next != head) 
            			current = current.next; 
		 	current.next = r; 
        			r.next = head; 
        			head = r; 
    		} 
    		else
    		{
        while (current.next != head && current.next.data < r.data) 
            			current = current.next; 
			r.next = current.next; 
        			current.next = r; 
    		} 
          }
         void printList() 
	      { 
    		if (head != null) 
   		  { 
        	 Node temp = head; 
       		do
       			{ 
            	 System.out.print(temp.data + " "); 
           		temp = temp.next; 
        		}  while (temp != head); 
    		} 
	}
    public static void main(String[] args) 
	{ 
       CircularLinkedList list = new CircularLinkedList(); 
       int arr[] = new int[] {13, 25, 34, 12, 11, 30}; 
      Node temp = null; 
      for (int i = 0; i < arr.length; i++) 
    	{ 
       	 temp = new Node(arr[i]); 
         list.sortedInsert(temp); 
    	} 
          list.printList(); 
	    }		 
}
