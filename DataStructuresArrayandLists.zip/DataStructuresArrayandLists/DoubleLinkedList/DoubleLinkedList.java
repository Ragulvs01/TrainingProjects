package com;

public class DoubleLinkedList { 
    	Node head; 
       class Node 
        { 
         int data; 
       	 Node prev; 
         Node next; 
        Node(int a) 
       { 
        data = a; 
       } 
  }
  public void push(int new_data) 
   	{ 
      Node r = new Node(new_data); 
      r.next = head; 
      r.prev = null; 
      if (head != null) 
      head.prev = r; 
      head = r; 
    } 
   public void InsertAfter(Node prev_Node, int new_data) 
    	{ 
      if (prev_Node == null) 
          { 
           System.out.println("The given previous node cannot be NULL "); 
   			return; 
          } 	
     Node r = new Node(new_data); 
     r.next = prev_Node.next; 
     prev_Node.next = r; 
      r.prev = prev_Node; 
    if (r.next != null) 
     	r.next.prev = r; 
    	} 
    	void append(int new_data) 
    	{ 
       Node r = new Node(new_data); 
  		Node last = head; 
       r.next = null;
     if (head == null) 
          { 
           	r.prev = null; 
        	head = r; 
         	return; 
        } 
        while (last.next != null) 
           last = last.next; 
           last.next = r; 
           r.prev = last; 
    	} 
   public void printlist(Node node) 
    	      { 
        		Node last = null; 
        		System.out.println("Traversal in forward Direction"); 
        		while (node != null) 
               { 
         		System.out.print(node.data + " "); 
            			last = node; 
            			node = node.next; 
        		} 
        		System.out.println(); 
        		System.out.println("Traversal in reverse direction"); 
        		while (last != null) 
              { 
            	System.out.print(last.data + " "); 
           		last = last.prev; 
        		} 
    	}
     public static void main(String[] args) 
     {
       DoubleLinkedList d = new DoubleLinkedList();
       d.append(19); 
       d.push(27);
       d.push(31); 
       d.append(12); 
       d.InsertAfter(d.head.next, 5); 
  		System.out.println("Doubly LinkedList is: "); 
        d.printlist(d.head); 
    	}
}
