import java.util.*;
public class LongestIncresingSubsequence {
	public static void main(String[] args) {
	 int a[]=new int[10000];
	 int n;
	 Scanner s= new Scanner(System.in);
	 System.out.println("Enter the number of elements in an array");
	    n= s.nextInt();
	  System.out.println("Enter the elements in an array");
	    for(int k=0;k<n;k++) {
	    	a[k]= s.nextInt();
	    }
       ArrayList<Integer> b = new ArrayList<Integer>();
       ArrayList<Integer> c= new ArrayList<Integer>();
       int Max;
       int Count = 0;
       for(int i = 0; i < n;i++)
       {
           Max = Integer.MIN_VALUE;
           for(int j = i;j < n; j++)
           {
               if(a[j] > Max)
               {
                   b.add(a[j]);
                   Max = a[j];
               }
           }
           if(Count < b.size())
           {
               Count = b.size();
               c = new ArrayList<Integer>(b); 
           }  
           b.clear();
       }
       Iterator<Integer> d = c.iterator();
       System.out.println("The subsequence is");
       while(d.hasNext())
       {
           System.out.print(d.next() + " ");
       }
       System.out.println();
       System.out.println("Length of subsequence is : " + Count);
   }
}
