package com;
import java.util.*;
public class KthSmallestElement {
	static int findMedian(int a[], int i,int n)
	{
	        Arrays.sort(a, i, n);
	        return a[i+(n-i)/2];                    
	}
	static int kthSmallest(int a[], int l, int r, int k)
	{
	    if (k > 0 && k <= r - l + 1)
	    {
	        int n = r - l + 1 ; 
	        int i;
	        int []mid = new int[(n + 4) / 5];
	        for (i = 0; i < n/5; i++)
	            mid[i] = findMedian(a, l+i*5, l+i*5+5);
	        if (i*5 < n) 
	        {
	            mid[i] = findMedian(a, l+i*5, l+i*5+n%5); 
	            i++;
	        } 
	        int medOfMed = (i == 1)? mid[i - 1]:
	                                kthSmallest(mid, 0, i - 1, i / 2);
	        int pos = partition(a, l, r, medOfMed);
	        if (pos-l == k - 1)
	            return a[pos];
	        if (pos-l > k - 1) 
	            return kthSmallest(a, l, pos - 1, k);
	        return kthSmallest(a, pos + 1, r, k - pos + l - 1);
	    }
	    return Integer.MAX_VALUE;
	}
	static int[] swap(int []a, int i, int j)
	{
	    int temp = a[i];
	    a[i] = a[j];
	    a[j] = temp;
	    return a;
	}
	static int partition(int a[], int l,int r, int x)
	{
	    int i;
	    for (i = l; i < r; i++)
	        if (a[i] == x)
	        break;
	    swap(a, i, r);
	    i = l;
	    for (int j = l; j <= r - 1; j++)
	    {
	        if (a[j] <= x)
	        {
	            swap(a, i, j);
	            i++;
	        }
	    }
	    swap(a, i, r);
	    return i;
	}
	public static void main(String[] args) {
		int arr[] = {12, 3, 5, 7, 4, 19, 26}; 
	    int n = arr.length, k = 5;
	    System.out.println("K'th smallest element is "
	        + kthSmallest(arr, 0, n - 1, k));
	}
}
