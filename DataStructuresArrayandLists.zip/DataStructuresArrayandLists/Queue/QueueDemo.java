package com;
import java.util.*;
public class QueueDemo {
	public static void main(String[] args) {
		  Queue<String> s = new LinkedList<String>();
		  s.add("Ram");
	      s.add("Gopal");
    	  s.add("Somu");
		  s.add("Venu");
		  s.add("Nandha");
		  System.out.println("Queue : " + s);
		  System.out.println("Head is: " +s.peek());
		  s.remove();
		  System.out.println("After removing : " + s);
		  System.out.println("Size is : " + s.size());
		 }
}

