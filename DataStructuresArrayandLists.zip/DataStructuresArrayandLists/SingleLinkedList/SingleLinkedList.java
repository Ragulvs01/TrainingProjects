package com;

public class SingleLinkedList {
	Node head;
	static class Node 
          { 
    		int data; 
    		Node next; 
    		Node(int a) 
    		{ 
        	data = a; 
        	next = null; 
    		} 
	      } 
	public static SingleLinkedList insertnode(SingleLinkedList list, int data) 
	{ 
    		Node r = new Node(data); 
    	         r.next = null;  
    		if (list.head == null) 
             { 
        			list.head = r; 
    		} 
    		else 
                   {  
        			Node last = list.head; 
        			while (last.next != null) 
                    { 
            			last = last.next; 
        			}  
        			last.next = r; 
    		} 
    		return list; 
	} 
	public static void printList(SingleLinkedList list) 
	{	 
    		Node currentNode = list.head; 
    		System.out.print("LinkedList is : "); 
    		while (currentNode != null) 
              { 
        			System.out.print(currentNode.data + " "); 
        			currentNode = currentNode.next; 
    		} 
    		System.out.println(); 
	   } 
	public static SingleLinkedList deletenode(SingleLinkedList list, int key) 
	  { 
    		Node currentNode = list.head, prev = null; 
    		if (currentNode != null && currentNode.data == key) 
               { 
        			list.head = currentNode.next; 
        			System.out.println(key + " found"); 
        			return list; 
    		} 
    		while (currentNode != null && currentNode.data != key) 
          { 
        			prev = currentNode; 
        			currentNode = currentNode.next; 
    		} 
    		if (currentNode != null) 
                { 
        			prev.next = currentNode.next; 
        			System.out.println(key + " Deleted"); 
    		} 
    		if (currentNode == null) 
             { 
        			System.out.println(key + " not found"); 
    		} 
    		return list; 
	} 
	public static void main(String[] args) 
	{ 
    		SingleLinkedList list = new SingleLinkedList(); 
    		list = insertnode(list, 11); 
    		list = insertnode(list, 22); 
    		list = insertnode(list, 33); 
    		list = insertnode(list, 44); 
    		list = insertnode(list, 55); 
    		list = insertnode(list, 66); 
    		list = insertnode(list, 77); 
    		list = insertnode(list, 88); 
    		printList(list);
      		deletenode(list, 22); 
       		printList(list); 
     		deletenode(list, 43); 
    		printList(list); 
    		deletenode(list, 10); 
     		printList(list); 
	} 
} 
