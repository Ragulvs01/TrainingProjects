package com;
import java.util.*;
public class StackDemo {
	public static void main(String[] args) {
		{
	        Stack<String> s= new Stack<String>();
	        s.push("hi");
	        s.push("all");
	        s.push("welcome");
	        s.add("to");
	        s.push("2022");
	        System.out.println("Stack: " + s);
	        String rem_ele = s.pop();
	        System.out.println("Removed element: "+ rem_ele);
	        String rem_ele1 = s.remove(3);
	        System.out.println("Removed element: "+ rem_ele1);
	        System.out.println("Final Stack: "+ s);
	    }
	}
}
