package com.service;
import com.bean.Product;
import com.dao.ProductDao;
public class ProductService {
ProductDao pro = new ProductDao();
    public String storeProduct(Product pr) {
    	if(pro.storeProduct(pr)>0) {
    		return"Product Details Added Succesfully";
    	}else {
    		return"There is an error in inserting the Product";
    	}
    }
}
