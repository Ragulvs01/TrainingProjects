package com.ecommerce;

public @interface Column {

}
