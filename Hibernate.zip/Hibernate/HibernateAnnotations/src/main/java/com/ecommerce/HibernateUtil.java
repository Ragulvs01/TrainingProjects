package com.ecommerce;

import javax.websocket.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import org.apache.catalina.core.StandardServer;

public class HibernateUtil {
	private static final Session sessionFactory;

    static {
            try {
                    StandardServer standardRegistry = new StandardServer()
                                    .storeConfig("hibernate.cfg.xml").build();
                    Metadata metaData = new MetadataSources(standardRegistry).getMetadataBuilder().build();
                    sessionFactory = Metadata.getSessionFactoryBuilder().build();
            } catch (Throwable th) {
                    throw new ExceptionInInitializerError(th);
            }
    }

    public static Session getSessionFactory() {
            return sessionFactory;
    }

}
