package com.main;
import java.util.*;
import com.bean.Employee;
import com.service.EmployeeService;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp1 = new Employee();
        emp1.setId(15);
        emp1.setName("jesh");
        emp1.setSalary(190);
        
        EmployeeService es = new EmployeeService();
        System.out.println("Es created");
        String result = es.storeEmployee(emp1);
        System.out.println(result);
	//	EmployeeService es = new EmployeeService();
	//	List<Employee>listOfEmp = 
		
		//for(Employee emp:listOfEmp){
		//	System.out.println(emp);
		//}
    //  }*/
}
}