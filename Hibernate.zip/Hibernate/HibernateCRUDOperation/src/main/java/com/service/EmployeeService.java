package com.service;
import java.util.*;
import com.bean.Employee;
import com.dao.EmployeeDao;

public class EmployeeService {
EmployeeDao ed = new EmployeeDao();
    
    public String storeEmployee(Employee emp) {
    	System.out.println("Inside StoreEmployee");
        if(emp.getSalary()<100) {
            return "Employee salary must be > 100";
        }else if(ed.storeEmployee(emp)>0) {
            return "Record inserted successfully";
        }else {
            return "Record didn't insert";
        }
    }
  /*  public List<Employee> getAllEmployee() {
        List<Employee> listOfEmp = ed.getAllEmployee();
        Iterator<Employee> li = listOfEmp.iterator();
        while(li.hasNext()) {
            Employee emp = li.next();
            emp.setSalary(emp.getSalary()+500);
        }
        
        return listOfEmp;
   }*/
}