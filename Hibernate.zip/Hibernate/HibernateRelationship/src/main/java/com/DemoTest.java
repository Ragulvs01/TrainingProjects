package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration con=new Configuration();
	       con.configure("hibernate.cfg.xml");
	       SessionFactory sf= con.buildSessionFactory();
	       Session session =sf.openSession();
	       Transaction tran= session.getTransaction();
	       System.out.println("Table");
	  /* Trainer tr=new Trainer();
	   tr.setTid(101);
	   tr.setTname("Ajay");
	   tran.begin();
	     session.save(tr);
	    tran.commit();
	    System.out.println("Added successfully");*/
	   /* Students s1=new Students();
	    s1.setSid(13);
	    s1.setSname("Gokul");
	    s1.setAge(24);
	    tran.begin();
	       session.save(s1);
	       tran.commit();
	       System.out.println("Students added successfully");*/
	     /*  Course c1= new Course();
	       c1.setCname("python");
	       c1.setFees(28000);
	       tran.begin();
	         session.save(c1);
	         tran.commit();
	         System.out.println("Course added successfully");*/
	    /* Students s1= session.get(Students.class,12);
	     if(s1==null) {
	    	 System.out.println("Student not present");
	     }else {
	    	 tran.begin();
	    	 s1.setTsid(101);
	    	 session.update(s1);
	    	 tran.commit();
	    	 System.out.println("Student assigned present");
	     }*/
	}

}
