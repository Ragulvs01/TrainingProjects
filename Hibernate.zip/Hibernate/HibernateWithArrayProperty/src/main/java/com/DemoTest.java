package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Configuration con=new Configuration();
       con.configure("hibernate.cfg.xml");
       SessionFactory sf= con.buildSessionFactory();
       Session session =sf.openSession();
       Transaction tran= session.getTransaction();
       Question q1=new Question();
       q1.setPid(2);
       q1.setQuestion("4+4");
       String ans[]= {"9","6","10","8"};
       q1.setAnswers(ans);
       q1.setCorrectAnswer("8");
       tran.begin();
        session.save(q1);
       tran.commit();
       System.out.println("Stored");
	}

}
