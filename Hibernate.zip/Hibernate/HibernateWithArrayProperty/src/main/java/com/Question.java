package com;

import java.util.Arrays;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OrderColumn;
@Entity
public class Question {
	@Id
private int pid;
private String question;
@ElementCollection
@OrderColumn(name="answerID")
@CollectionTable(name="answer")
private String answers[];
private String correctAnswer;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
public String[] getAnswers() {
	return answers;
}
public void setAnswers(String[] answers) {
	this.answers = answers;
}
public String getCorrectAnswer() {
	return correctAnswer;
}
public void setCorrectAnswer(String correctAnswer) {
	this.correctAnswer = correctAnswer;
}
@Override
public String toString() {
	return "Question [pid=" + pid + ", question=" + question + ", answers=" + Arrays.toString(answers)
			+ ", correctAnswer=" + correctAnswer + "]";
}

}
