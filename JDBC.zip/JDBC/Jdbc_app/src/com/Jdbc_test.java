package com;
import java.sql.*;
import java.util.*;
public class Jdbc_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      try {
    	 // Class.forName("com.mysql.jdbc.cj.Driver");
    	  Class.forName("com.mysql.cj.jdbc.Driver");
    	  System.out.println("Driver loaded succsessfully");
    	 Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/javatraining","root","Chandr@1");
    	 System.out.println("Conneceted succsessfully");
    	 
    	 Statement stmt= con.createStatement();
    	 System.out.println("Statement is ready");
    	 Scanner obj=new Scanner(System.in);
    	/*int res= stmt.executeUpdate("insert into employee values(6,'van',600)");
    	if(res>0) {
    		System.out.println("the value is added");
    	}*/
    	/* PreparedStatement pstmt= con.prepareStatement("insert into employee values(?,?,?)");
    	 System.out.println("ENter the id");
    	 int id= obj.nextInt();
    	 pstmt.setInt(1,id);
    	 System.out.println("ENter the name");
    	 String name= obj.next();
    	 pstmt.setString(2,name);
    	 System.out.println("ENter the salary");
    	 float salary= obj.nextInt();
    	 pstmt.setFloat(3,salary);
    	 int res= pstmt.executeUpdate();
    	 if(res>0) {
    		 System.out.println("The insertion done");
    	 }*/
    	/* PreparedStatement pstmt= con.prepareStatement("delete from employee where id=?");
    	 System.out.println("ENter the id");
    	 int id= obj.nextInt();
    	 pstmt.setInt(1,id);
    	 int res= pstmt.executeUpdate();
    	 if(res>0) {
    		 System.out.println("The value deleted Successfully");
    	 }*/
    	 
    	/* int res= stmt.executeUpdate("delete from employee where id =1");
    	 if(res>0) {
    		 System.out.println("Deleted succsessfully");
    	 }else {
    		 System.out.println("value not found");
    	 }	*/
    // int res= stmt.executeUpdate("update employee set salary =4000 where id =1");
   	 //if(res>0) {
   		// System.out.println("Updated succsessfully");
   //	 }else {
   	//	 System.out.println("value not found");
   	 //}
    	// ResultSet rs=stmt.executeQuery("select * from employee");
    		//	 while(rs.next()) {
    			//	 System.out.println("id is "+ rs.getInt(1)+" the name is "+rs.getString(2)+" the salary is "+rs.getFloat(3));
    			 //}
    			 //rs.close();
    	 PreparedStatement pstmt=con.prepareStatement("Select * from employee");
    	 ResultSet rs=pstmt.executeQuery();
 		 while(rs.next()) {
 		System.out.println("id is "+ rs.getInt(1)+" the name is "+rs.getString(2)+" the salary is "+rs.getFloat(3));
 		}
 		rs.close();
    	stmt.close();
    	con.close();
    	}catch(Exception e) {
    	  System.out.println(e);
      }
	}

}
