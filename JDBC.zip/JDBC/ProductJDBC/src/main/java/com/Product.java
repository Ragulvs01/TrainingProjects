package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Product
 */
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Product() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw = response.getWriter();
		String id = request.getParameter("id");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
	    	Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/javatraining","root", "Chandr@1");
	    	PreparedStatement pstmt=con.prepareStatement("Select * from product where id ="+id);
	    	 ResultSet rs=pstmt.executeQuery();
	 		 if(rs.next()) {
	 		pw.println("The product Id you entered "+ rs.getInt(1)+" is the ID for the product "+rs.getString(2)+" and the price amount is "+rs.getFloat(3));
	 		}else {
	 			pw.println("Please enter the correct ID");
	 		}
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
