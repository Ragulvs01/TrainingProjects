package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Product {
		// TODO Auto-generated method stub
	  private Connection connection;        
	   public Product(String dbURL, String user, String pwd) throws ClassNotFoundException, SQLException{                
		         Class.forName("com.mysql.jdbc.Driver");
		        this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/javatraining","root","Chandr@1");
		     }
		    public Connection getConnection(){
	        return this.connection;
	        }
	       public void closeConnection() throws SQLException {
	         if (this.connection != null)
	         this.connection.close();
	        }   
	}

