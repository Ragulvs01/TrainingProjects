package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.Employee;

public class EmployeeService {
 public String checkUser(String emailid, String password) {
	 if(emailid.equals("raj@gmail.com")&&password.equals("123")) {
		 return "success";
	 }else {
		 return "failure";
	 }
 }
 public Employee getEmployee() {
	 Employee emp= new Employee();
	 emp.setId(100);
	 emp.setName("ram");
	 emp.setSalary(14000);
	 return emp;
 }
 public List<Employee> ListofEmployee(){
	 List<Employee> listofemp=new ArrayList<Employee>();
	 Employee emp1= new Employee();
	 emp1.setId(10);
	 emp1.setName("sam");
	 emp1.setSalary(12000);
	 Employee emp2= new Employee();
	 emp2.setId(112);
	 emp2.setName("cam");
	 emp2.setSalary(16000);
	 listofemp.add(emp2);
	 listofemp.add(emp1);
	 return listofemp;
 }
 public float passEmployeeObject(Employee emp) {
	 return emp.getSalary()+500;
	 }
}
