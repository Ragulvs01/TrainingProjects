package com.test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.List;
import java.util.*;
import org.junit.jupiter.api.Test;

import com.bean.Employee;
import com.service.EmployeeService;

class EmployeeServiceTest {

	@Test
	void testCheckUser() {
		//fail("Not yet implemented");
		EmployeeService es= new EmployeeService();
		String res=es.checkUser("raj@gmail.com","123");
		assertEquals("success", res);
		String res1=es.checkUser("ram@gmail.com","123");
		assertEquals("success", res1);
	}

	@Test
	void testGetEmployee() {
		//fail("Not yet implemented");
		EmployeeService es=new EmployeeService();
		Employee emp= es.getEmployee();
		assertNotNull(emp);
		assertEquals(100, emp.getId());
		assertEquals("ram", emp.getName());
		assertEquals(14000, emp.getSalary());
	}

	@Test
	void testListofEmployee() {
		//fail("Not yet implemented");
		EmployeeService es=new EmployeeService();
		java.util.List<Employee> listofemp =es.ListofEmployee();
		assertEquals(2, listofemp.size());
	}

	@Test
	void testPassEmployeeObject() {
		fail("Not yet implemented");
		EmployeeService es=new EmployeeService();
		Employee emp= es.getEmployee();
		emp.setId(100);
		emp.setName("ram");
		emp.setSalary(1200);
		float updatedSalary= es.passEmployeeObject(emp);
		assertEquals(1700, updatedSalary);
	}

}
