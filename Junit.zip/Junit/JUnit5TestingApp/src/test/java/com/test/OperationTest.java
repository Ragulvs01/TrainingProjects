package com.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.service.Operation;

class OperationTest {

	@Test
	void testAdd() {
		//fail("Not yet implemented");
		Operation op= new Operation();
		int res=op.add(100, 10);
		assertEquals(110, res);
	}

	@Test
	void testSub() {
		//fail("Not yet implemented");
		Operation op= new Operation();
		int res=op.sub(100, 10);
		assertEquals(90, res);
	}

	@Test
	void testMul() {
		//fail("Not yet implemented");
		Operation op= new Operation();
		int res=op.mul(10, 10);
		assertEquals(100, res);
	}

	@Test
	void testDiv() {
		//fail("Not yet implemented");
		Operation op= new Operation();
		int res=op.div(50, 5);
		assertEquals(10, res);
	}

}
