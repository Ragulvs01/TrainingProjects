package com.service;
import java.util.ArrayList;
import java.util.List;
import com.bean.User;
public class UserAutentication {
	List<User> lists= new ArrayList<>();;
	public boolean Login(User u)
	{
		boolean res=false;
		for (User user : lists) {
			if(!user.getEmail().equals(u.getEmail())&&user.getPassword().equals(u.getPassword()))
			{	
				 res= false;
				break;	
			}
			else
			{
				res= true;
				break;
			}
		}
		return res;
	}
	public List<User> listOfUser(User u)
	{
		this.lists.add(u);
		return lists;
	}
	public String registration(User u)
	{
		String res=null;
		for (User user : lists) {
			if(user.getEmail().equals(u.getEmail()))
			{
				
				 res= "Email already exists";
				break;
			}
			else
			{
				listOfUser(u);
				res= "Email is Registered";
				break;
			}
		}
		return res;		
	}
}
