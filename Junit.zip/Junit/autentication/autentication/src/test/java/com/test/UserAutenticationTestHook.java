package com.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Scanner;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bean.User;
import com.service.UserAutentication;

class UserAutenticationTestHook {
	static User u;
	static UserAutentication ua ;
	static Scanner sc;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		u=new User();
		ua = new UserAutentication();
		ua.listOfUser( new User("ragul@gmail.com","ragul"));
	}
	@AfterAll
	static void tearDownAfterClass() throws Exception {
		u=null;
		ua=null;
	}
	@BeforeEach
	void setUp() throws Exception {
		sc = new Scanner(System.in);	
	}
	@AfterEach
	void tearDown() throws Exception {
		sc.close();
	}
	@Test
	void testLogin() {
		//fail("Not yet implemented");
		System.out.println("enter your emailId and password to login");
		u.setEmail(sc.next());
		u.setPassword(sc.next());
		assertTrue(ua.Login(u));
		//assertFalse(ua.Login(new User("makesh@gmail.com","makesh")));	
	}
	@Test
	void testListOfUser() {
		//fail("Not yet implemented");	
		assertNotNull(ua.listOfUser(new User("ravi@gmail.com","ravi")));
	}
	@Test
	void testRegistration() {
		//fail("Not yet implemented");
		assertEquals("Email is Registered", ua.registration(new User("ram@gmail.com","ram")));
		assertEquals("Email already exists", ua.registration(new User("ragul@gmail.com","ragul")));
	}
}
