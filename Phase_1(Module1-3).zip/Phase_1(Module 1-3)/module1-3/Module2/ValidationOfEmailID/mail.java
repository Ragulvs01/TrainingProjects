import java.util.ArrayList;
import java.util.Scanner;
public class mail {
   public static void main(String[] args) {  
	   Scanner s= new Scanner(System.in);
	   System.out.println("Enter the number of mailIds for the Array list");
	   int r= s.nextInt();
	   ArrayList<String> mailid = new ArrayList<String>();
	   for(int k=0;k<r;k++) {
		   System.out.println("Enter the mailID "+(k+1));
		   String i= s.next();
		   mailid.add(i);
	   }
     String search = null;
        System.out.println("Enter the email to search");      
        try (Scanner input = new Scanner(System.in)) {
			System.out.println("Enter email Id : ");
         search = input.nextLine(); 
		}
            if(mailid.contains(search)){
         System.out.println("emailID " + search + " found");
     }
     else{
         System.out.println( "emailID " + search + " not found");
     }
   }
}
