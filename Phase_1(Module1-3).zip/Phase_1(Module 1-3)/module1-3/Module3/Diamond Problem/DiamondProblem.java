package Module1;
interface Team1{
	 default void display()
	 {
		 System.out.println("First interface");
	 }
}
interface Team2{
	default void display2()
	 {
		 System.out.println("Second interface");
	 }
}
public class DiamondProblem implements Team1, Team2{
	public void show() {
		Team1.super.display();
		Team2.super.display2();
	}
	
    public static void main(String[]args) {
    	DiamondProblem ob=new DiamondProblem();
    	ob.show();
    }
}
