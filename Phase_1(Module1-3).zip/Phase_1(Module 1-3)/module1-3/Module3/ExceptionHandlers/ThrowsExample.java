package com;

public class ThrowsExample {
    static void dis1() throws Exception {
    	int a=10/0;
    	System.out.println("Display1");
    }
    static void dis2()throws Exception {
    	dis1();
    	System.out.println("Display2");
    }
	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub  
		   dis2();
	    	System.out.println("Main method");
	}

}
