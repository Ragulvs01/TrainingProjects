package com;
import java.io.*;
import java.util.Scanner;
public class FileHandling {
	public static void main(String[] args)throws FileNotFoundException, IOException {
		System.out.println("Please select one of the below operations");
        System.out.println(" w is for write");
        System.out.println(" r is for read");
        System.out.println(" a is for append");
        Scanner s =new Scanner(System.in);
        String r=s.nextLine();
        if(r.equalsIgnoreCase("r"))
        {
            new FileReading();
        }
        else if(r.equalsIgnoreCase("w"))
        {
        	FileWriting(r);    
        }
        else if(r.equalsIgnoreCase("a"))
        {
        	FileWriting(r);    
        }
        else
        {
            System.out.println("kindly choose one of the above option only");
        }   
       s.close();  
    } 
    public static void FileWriting(String r)
    {
        Scanner s=null;
        try
        {
            String srce = "";
            File file=new File("text.txt");
            BufferedReader b=new BufferedReader(new InputStreamReader(System.in)); 
            FileWriter fw =null;
            if(r.equalsIgnoreCase("w"))
            {
                fw = new FileWriter(file,false);
                System.out.println("It not only add the text to file and it will also delete the already presented files");
                System.out.println("If you want to add to an already existing one Kindly choose no after running again type Append(a)");
                System.out.println("");
                System.out.println("If you want to procced type 'yes' or type'no'");
                s=new Scanner(System.in);
                String s1=s.nextLine();
                if(s1.equalsIgnoreCase("no"))
                System.exit(0);
                else if(s1.equalsIgnoreCase("yes")) {
                System.out.println("After Writing the content please write 'end' ");
                file.delete();
                file.createNewFile();
                while(!(srce=b.readLine()).equalsIgnoreCase("end")){
                    fw.write(srce + System.getProperty("line.separator"));  
                } 
                s.close();
                }
                else {
                	System.exit(0);
                }
            }
            else
            {  fw = new FileWriter(file,true);
                System.out.println("After Writing the content please write 'end'");
                while(!(srce=b.readLine()).equalsIgnoreCase("end")){
                    fw.append(srce+ System.getProperty("line.separator"));
                }
            }
            fw.close(); 
        }
        catch(Exception e){
            System.out.println("There is some error in this program" );
            e.printStackTrace();
        }       
    }    
}
class FileReading{
    public static String r="";
    public FileReading() {
        try{
            File fr=new File("text.txt");
            if(! fr.exists())
            fr.createNewFile();
            FileReader fl=new FileReader(fr);
            BufferedReader bf=new BufferedReader(fl);
            while((r=bf.readLine())!=null){
                System.out.println(r);
            }
            fl.close();
            }catch(Exception e){
            System.out.println("There is some error in this program");
            e.printStackTrace();
        }	
	}
}
