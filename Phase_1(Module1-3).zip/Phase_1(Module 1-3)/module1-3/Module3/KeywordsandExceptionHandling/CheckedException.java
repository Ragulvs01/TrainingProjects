package com;

public class CheckedException {
	public static void main(String[] args)throws Exception {
		   System.out.println("hii");
		   try {
			   int a=10;
			   int r=a/0;
			   Thread.sleep(2000);
		   }catch(Exception e) {
			 System.out.println("There is an error");   
		   }
	   	System.out.println("Main method");
}
}