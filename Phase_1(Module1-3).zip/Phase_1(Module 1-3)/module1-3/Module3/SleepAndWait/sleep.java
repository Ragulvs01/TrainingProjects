package module1;
import java.io.*;
public class sleep {
	    private static Object s = new Object();
	    public static void main(String args[]) throws InterruptedException
	    {
	        Thread.sleep(1000);
	        System.out.println("Thread '" + Thread.currentThread().getName());
	        synchronized (s) 
	        {
	            s.wait(1000);
	            System.out.println("this is display one second for 1 second");
	            s.wait(1000);
	            System.out.print("it will display after one minute");
	        }
	    }
}