package Module1;

public class Synchronization implements Runnable
{
    int ticket = 3;
    public void booking (String name, int wantedtickets)
    {
        if (wantedtickets <= ticket)
        {
            System.out.println (wantedtickets + " Ticket booked to " + name);
            ticket = ticket - wantedtickets;
        }
        else
        {
            System.out.println ("No tickets to book");
        }
    }
    public void run ()
    {
        String name = Thread.currentThread ().getName ();
        if (name.equals ("Sam"))
        {
            booking (name, 1);
        }
        else if (name.equals ("Ram"))
        {
            booking(name, 2);
        }
        else
        {
            booking (name, 0);
        }
    }
    public static void main (String[]args)
    {
        Synchronization s = new Synchronization ();
        Thread t1 = new Thread (s);
        Thread t2 = new Thread (s);
        Thread t3 = new Thread (s);
        t1.setName ("Sam");
        t2.setName ("Ram");
        t3.setName ("Dhanu");
        t1.start ();
        t2.start ();
        t3.start ();
    }
}
