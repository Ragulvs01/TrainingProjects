package module1;

public class tryandcatch {
   public static void main(String args[]) 
	 {
	  int a=10;
	  int b=0;
	  try 
	   {
	     int result=a/b;
	    }
	    catch (Exception e) 
	     {
	      System.out.println("There is some error"); 
	      }
	    finally 
	      {
	        System.out.println("Check the error and upadte it");
	      }
	    }
}
