package Access;
import java.io.File;  
	public class DeleteFile {
	  public static void main(String[] args) { 
	    File myObj = new File("C:\\\\Users\\\\ragul\\\\Desktop\\\\Trainerrepo\\\\test_app123\\\\file\\\\hello.txt"); 
	    if (myObj.delete()) { 
	      System.out.println("Deleted the file: " + myObj.getName());
	    } else {
	      System.out.println("Failed to delete the file.");
	    } 
	  } 
}

