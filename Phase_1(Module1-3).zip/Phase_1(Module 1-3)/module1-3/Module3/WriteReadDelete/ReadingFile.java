package Access;
import java.io.File;  
import java.io.FileNotFoundException;  
import java.util.Scanner; 
public class ReadingFile {
  public static void main(String[] args) {
    try {
      File obj = new File("C:\\Users\\ragul\\Desktop\\Trainerrepo\\test_app123\\file\\hello.txt");
      Scanner s = new Scanner(obj);
      while (s.hasNextLine()) {
        String d = s.nextLine();
        System.out.println(d);
      }
      s.close();
    } catch (FileNotFoundException e) {
      System.out.println("There is an error.");
      e.printStackTrace();
    }
  }
}
