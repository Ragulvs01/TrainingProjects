package Access;
import java.io.FileWriter;   
import java.io.IOException;  
public class WritingFile {
  public static void main(String[] args) {
    try {
      FileWriter obj = new FileWriter("C:\\Users\\ragul\\Desktop\\Trainerrepo\\test_app123\\file\\hello.txt");
      obj.write("Write something on file");
      obj.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("There is an error");
      e.printStackTrace();
    }
  }
}
