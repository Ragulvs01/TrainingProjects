package com;
class D implements Runnable {
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println("i"+i);
		}
	}
}
class C implements Runnable {
	public void run() {
		for(int j=0;j<10;j++) {
			System.out.println("j"+j);
		}
	}
}
public class ImplementsRunnable {
	public static void main(String[] args) {
		  D obj1=new D();
		   C obj2= new C();
		  // Thread t1=new Thread(obj1);
		   //Thread t2= new Thread(obj2);
		   obj1.run();
		   obj2.run();
	}
}
