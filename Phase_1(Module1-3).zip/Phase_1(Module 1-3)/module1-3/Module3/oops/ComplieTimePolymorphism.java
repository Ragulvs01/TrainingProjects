package Module1;
class Area{
	public void value(int x, int y) {
		int r=x*y;
		 System.out.println(r);
	}
	public void value(int x) {
		int r=x;
		System.out.println(r);
	}
}
public class ComplieTimePolymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Area obj1=new Area();
      obj1.value(4,5);
      obj1.value(3);
	}

}
