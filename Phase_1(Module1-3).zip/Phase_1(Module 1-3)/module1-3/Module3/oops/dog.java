package module1;

public class dog {
	    String name; 
	    String variety; 
	    String color; 
	    public dog(String name, String variety, String color) 
	    { 
	        this.name = name; 
	        this.variety = variety;  
	        this.color = color; 
	    } 
	    public String getName() 
	    { 
	        return name; 
	    } 
	    public String getvariety() 
	    { 
	        return variety; 
	    }  
	    public String getColor() 
	    { 
	        return color; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return("The dog name is "+ this.getName()+ ".\nMy variety is"+ this.getvariety()+ "and color are "+ this.getColor() + "."); 
	    } 
	    public static void main(String[] args) 
	    { 
	        dog Scuby = new dog("Ram","Sippiparai" ,"Brown"); 
	        System.out.println(Scuby.toString()); 
	    } 
}
