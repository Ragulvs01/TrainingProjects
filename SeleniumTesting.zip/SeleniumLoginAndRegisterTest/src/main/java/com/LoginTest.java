package com;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class LoginTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\Mphasis\\Learning Materials\\JavaPhase5\\program\\chromedriver_win32\\chromedriver.exe");
	    WebDriver wd= new ChromeDriver();
	    wd.get("http://127.0.0.1:5500/login.html");
	    WebElement emailref= wd.findElement(By.id("n1"));
	    emailref.sendKeys("ram@gmail.com");
	    WebElement passref= wd.findElement(By.id("n2"));
	    passref.sendKeys("123");
	    WebElement submitref= wd.findElement(By.id("b1"));
	    submitref.click();
	    Alert alertref= wd.switchTo().alert();
	    System.out.println(alertref.getText());
	    alertref.accept(); 
	    WebElement href= wd.findElement(By.id("b3"));
	    href.click();
	    ///Registration
	    WebElement emailr= wd.findElement(By.id("n3"));
	    emailr.sendKeys("ram@gmail.com");
	    WebElement passr= wd.findElement(By.id("n4"));
	    passr.sendKeys("123");
	    WebElement submitr= wd.findElement(By.id("b4"));
	    submitr.click();
	    Alert alertr= wd.switchTo().alert();
	    System.out.println(alertr.getText());
	    alertr.accept();
	    WebElement href1= wd.findElement(By.id("b5"));
	    href1.click();
	    //login
	    WebElement emailrl= wd.findElement(By.id("n1"));
	    emailrl.sendKeys("ram@gmail.com");
	    WebElement passrl= wd.findElement(By.id("n2"));
	    passrl.sendKeys("123");
	    WebElement submitrl= wd.findElement(By.id("b1"));
	    submitrl.click();
	    Alert alertrl= wd.switchTo().alert();
	    System.out.println(alertrl.getText());
	    alertrl.accept(); 
//	    //
//	    File screenshot = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
//	    try {
//            FileUtils.copyFile(screenshot, new File("D:\\Mphasis\\Learning Materials\\JavaPhase5\\SeleniumScreenShots\\homePageScreenshot.png"));
//        } catch (IOException e) {
//            System.out.println(e.getMessage());
//        }
	}

}
