function validateLogin(){
    //alert("Hello")
    var email= document.getElementById("n1").value
    var pass= document.getElementById("n2").value
    // if(email.length==0){
    //     alert("plz enter email ID")
    //     return false;
    // }else if(pass.length==0){
    //     alert("plz enter password")
    //     return false;
    // }else if(email=="ram@gmail.com" && pass=="123"){
    //     alert("Login Success")
    //     return true
    // }else{
    //     alert("Login Failure")
    //     return false
    // }
    // return true;
    var semail=sessionStorage.getItem("mailid")
    var spass=sessionStorage.getItem("password")
    if(email==semail && pass==spass){
        alert("login Success")
        return true
    }else{
        alert("Login Failure please register before login")
        return false
    }
}
function store(){
    var mail= document.getElementById("n3").value
    var pass1=document.getElementById("n4").value
    sessionStorage.setItem("mailid",mail)
    sessionStorage.setItem("password",pass1)
    alert("Registration Successful")
}