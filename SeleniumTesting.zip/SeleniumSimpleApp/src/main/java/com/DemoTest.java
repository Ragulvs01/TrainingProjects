package com;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\Mphasis\\Learning Materials\\JavaPhase5\\program\\chromedriver_win32\\chromedriver.exe");
    WebDriver wd= new ChromeDriver();
    wd.get("file:///D:/Mphasis/Learning%20Materials/JavaPhase5/program/index.html");
//    String titletag= wd.getTitle();
//    String url= wd.getCurrentUrl();
//    String pagecontent= wd.getPageSource();
//    System.out.println(titletag);
//    System.out.println(url);
//    System.out.println(pagecontent);
//    
    WebElement h1ref= wd.findElement(By.tagName("h1"));
    System.out.println(h1ref.getTagName()+" "+h1ref.getText());
    WebElement pref= wd.findElement(By.tagName("p"));
    System.out.println(pref.getTagName()+" "+pref.getText());
    WebElement divref= wd.findElement(By.tagName("div"));
    System.out.println(divref.getTagName()+" "+divref.getText());
    List<WebElement> listoftag= wd.findElements(By.tagName("p"));
    Iterator<WebElement> li= listoftag.iterator();
    while(li.hasNext()) {
    	WebElement ww= li.next();
    	System.out.println(ww.getTagName()+" "+ww.getText());
    }
    WebElement divid= wd.findElement(By.id("hi"));
    System.out.println(divid.getTagName()+" "+divid.getText());
    wd.close();
	}

}
