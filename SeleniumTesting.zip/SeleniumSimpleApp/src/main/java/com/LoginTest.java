package com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\Mphasis\\Learning Materials\\JavaPhase5\\program\\chromedriver_win32\\chromedriver.exe");
	    WebDriver wd= new ChromeDriver();
	    wd.get("file:///D:/Mphasis/Learning%20Materials/JavaPhase5/program/login.html");
//	    String sourcepage= wd.getCurrentUrl();
//	    System.out.println(sourcepage);
//	    WebElement h1ref= wd.findElement(By.tagName("h1"));
//	    System.out.println(h1ref.getText());
//	    WebElement emailref= wd.findElement(By.id("n1"));
//	    WebElement passref= wd.findElement(By.id("n2"));
//	    emailref.sendKeys("ram@gmail.com");
//	    passref.sendKeys("123");
//	    WebElement submitref= wd.findElement(By.id("b1"));
//	    submitref.click();
//	    String targetpage= wd.getCurrentUrl();
//	    System.out.println(targetpage);
//	    WebElement href= wd.findElement(By.tagName("h1"));
//	    System.out.println(href.getText());
//	    WebElement resetref= wd.findElement(By.id("b2"));
//        resetref.click();
	    
	    //email validation
//	    WebElement emailref= wd.findElement(By.id("n1"));
//	    WebElement passref= wd.findElement(By.id("n2"));
//	    WebElement submitref= wd.findElement(By.id("b1"));
//	    submitref.click();
//	    Alert alertref= wd.switchTo().alert();
//	    System.out.println(alertref.getText());
//	    alertref.accept(); 
	   // wd.close();
	    
	    //password validation
//	    WebElement emailref= wd.findElement(By.id("n1"));
//	    emailref.sendKeys("ram@gmail.com");
//	    WebElement passref= wd.findElement(By.id("n2"));
//	    WebElement submitref= wd.findElement(By.id("b1"));
//	    submitref.click();
//	    Alert alertref= wd.switchTo().alert();
//	    System.out.println(alertref.getText());
//	    alertref.accept(); 
	    
	    //login success
//	    WebElement emailref= wd.findElement(By.id("n1"));
//	    emailref.sendKeys("ram@gmail.com");
//	    WebElement passref= wd.findElement(By.id("n2"));
//	    passref.sendKeys("123");
//	    WebElement submitref= wd.findElement(By.id("b1"));
//	    submitref.click();
//	    Alert alertref= wd.switchTo().alert();
//	    System.out.println(alertref.getText());
//	    alertref.accept(); 
//	    WebElement h1ref= wd.findElement(By.tagName("h1"));
//	    System.out.println(h1ref.getText());
	    
	    //login Failure
	    WebElement emailref= wd.findElement(By.id("n1"));
	    emailref.sendKeys("ram@gmail.com");
	    WebElement passref= wd.findElement(By.id("n2"));
	    passref.sendKeys("122");
	    WebElement submitref= wd.findElement(By.id("b1"));
	    submitref.click();
	    Alert alertref= wd.switchTo().alert();
	    System.out.println(alertref.getText());
	    alertref.accept(); 
	}
}
