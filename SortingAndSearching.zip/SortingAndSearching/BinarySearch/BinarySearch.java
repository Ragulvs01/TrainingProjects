package com;
import java.util.Scanner;
public class BinarySearch {
	public static int Search(int a[], int l, int r, int x)
    {
        if (r >= l) {
            int m = l + (r - l) / 2;
            if (a[m] == x)
                return m;
            if (a[m] > x)
                return Search(a, l, m - 1, x);
            return Search(a, m + 1, r, x);
        }
        return -1;
    }
	public static void main(String[] args) {
		int a[]=new int[10000];
		 int r,x;
		 Scanner s= new Scanner(System.in);
		 System.out.println("Enter the number of elements in an array");
		    r= s.nextInt();
		  System.out.println("Enter the elements in an array");
		    for(int k=0;k<r;k++) {
		    a[k]= s.nextInt();
		    }
        System.out.println("Enter the number to search");
        x= s.nextInt();
        
        int result = Search(a, 0, r - 1, x);
        if (result == -1)
            System.out.println("Element not present");
        else
            System.out.println("Element found at index " + result);

	}

}
