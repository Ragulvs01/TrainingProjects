package com;
import java.util.Arrays;
import java.util.Scanner;
public class ExponentialSearch {
    private static int binarySearch(int a[], int l, int r, int x)
    {
        if (l > r) {
            return -1;
        }
          int m = (l + r) / 2;
         if (x == a[m]) {
            return m;
        }
         else if (x < a[m]) {
            return binarySearch(a, l, m - 1, x);
        }
        else {
            return binarySearch(a, m + 1, r, x);
        }
    }
    public static int exponentialSearch(int b[], int y)
    {
        if (b == null || b.length == 0) {
            return -1;
        }
        int limit = 1;
        while (limit < b.length && b[limit] < y) {
            limit *= 2;        
        }
        return binarySearch(b, limit/2, Integer.min(limit, b.length - 1), y);
    }
    public static void main(String[] args)
    {
    	int a[]=new int[10000];
		 int r,x;
		 Scanner s= new Scanner(System.in);
		 System.out.println("Enter the number of elements in an array");
		    r= s.nextInt();
		  System.out.println("Enter the elements in an array");
		    for(int k=0;k<r;k++) {
		    a[k]= s.nextInt();
		    }
       System.out.println("Enter the number to search");
       x= s.nextInt();
        int result = exponentialSearch(a, x);
 
        if (result != -1) {
            System.out.println("Element found at position " + result);
        }
        else {
            System.out.println("Element is not found");
        }
    }
}
