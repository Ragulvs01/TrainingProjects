package com;

import java.util.Scanner;

public class LinearSearch {
	 public static int search(int a[],int x)
	    {  
	        int n = a.length;
	        for (int i = 0; i < n; i++)
	        {
	          if (a[i] == x) 
	                return i;
	          break;
	        }
	        return -1;
	        }
      public static void main(String args[])
	    {
    	  int a[]=new int[10000];
    		 int r,x;
    		 Scanner s= new Scanner(System.in);
    		 System.out.println("Enter the number of elements in an array");
    		    r= s.nextInt();
    		  System.out.println("Enter the elements in an array");
    		    for(int k=0;k<r;k++) {
    		    a[k]= s.nextInt();
    		    }
	         System.out.println("Enter the number to search");
	         x= s.nextInt();
	        int result = search(a, x);
	        if (result == -1)
	          System.out.println("Element is not present in array");
	        else
	         System.out.print("Element is present at index "+ result);
	    }
	}
