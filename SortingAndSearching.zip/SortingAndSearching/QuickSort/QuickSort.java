package com;

public class QuickSort {
	static void swap(int a[], int i, int j)
	{
	    int temp = a[i];
	    a[i] = a[j];
	    a[j] = temp;
	}
	static int partition(int a[], int l, int h)
	{
	    int pivot = a[h]; 
	    int i = (l - 1); 
	    for(int j = l; j <= h - 1; j++)
	    {
	        if (a[j] < pivot) 
	        {
	            i++; 
	            swap(a, i, j);
	        }
	    }
	    swap(a, i + 1, h);
	    return (i + 1);
	}
	static void quickSort(int a[], int l, int h)
	{
	    if (l < h) 
	    {
	        int pi = partition(a, l, h);
	        quickSort(a, l, pi - 1);
	        quickSort(a, pi + 1, h);
	    }
	}
	static void printArray(int[] arr, int size)
	{
	    for(int i = 0; i < size; i++)
	        System.out.print(arr[i] + " ");
	          
	    System.out.println();
	}

	public static void main(String[] args) {
		int[] arr = { 10, 7, 8, 9, 1, 5 };
	    int n = arr.length;
	    quickSort(arr, 0, n - 1);
	    System.out.println("Sorted array: ");
	    printArray(arr, n);
	}

}
