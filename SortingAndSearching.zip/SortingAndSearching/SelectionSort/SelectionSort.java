package com;
import java.util.Scanner;
public class SelectionSort {
	 void sort(int a[])
    {
        int n = a.length;
        for (int i = 0; i < n-1; i++)
        {
            int min = i;
            for (int j = i+1; j < n; j++)
                if (a[j] < a[min])
                    min = j;
            int temp = a[min];
            a[min] = a[i];
            a[i] = temp;
        }
    }
	 void printArray(int a[])
    {
        int n = a.length;
        for (int i=0; i<n; ++i)
            System.out.print(a[i]+" ");
        System.out.println();
    }
	public static void main(String[] args) {
		int a[] = {64,25,12,22,11};
		    SelectionSort obj =new SelectionSort();
	        obj.sort(a);
	        System.out.println("Sorted array");
	       obj.printArray(a);
	}
}
