package com.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.bean.User;
import com.service.UserService;
@Controller
public class MyController {
	@Autowired
	UserService service;
	@Autowired
	User u;
		@RequestMapping(value="/user",method=RequestMethod.POST)
		public ModelAndView userValues(HttpServletRequest request,HttpServletResponse response)
		{
			String email =request.getParameter("email");
			ModelAndView m = new ModelAndView(); 
			m.setViewName("hello.jsp");
			u=service.getUser(email);
			System.out.println(u.getId());
			m.addObject("user",u);
			return m;
		}
		@RequestMapping(value="/update",method=RequestMethod.POST)
		public ModelAndView updateUser(HttpServletRequest request,HttpServletResponse response)
		{
			String email =request.getParameter("email");
			u.setName(request.getParameter("name"));
			u.setAddress(request.getParameter("address"));
			u.setId(email);
			ModelAndView m = new ModelAndView(); 
			m.setViewName("index.jsp");
			String r=service.Update(u);
			System.out.println(r);
			m.addObject("result",r);
			return m;
		}
}

