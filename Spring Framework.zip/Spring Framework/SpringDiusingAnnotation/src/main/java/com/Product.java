package com;

public class Product {
  public void ProductInfo() {
	  System.out.println("product is created");
  }
}
