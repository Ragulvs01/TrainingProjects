package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Product;
import com.dao.ProductDao;

@Service
public class ProductService {
@Autowired
ProductDao productDao;
public String storeProduct(Product product) {
	if(product.getPrice()<1000) {
		return"Product price must be greater then 1000";
	}else if(productDao.storeProductDetails(product)>0) {
		return"Store Success";
	}else {
		return"failure";
	}
}
public String updateProduct(Product product) {
	if(productDao.updateProduct(product)>0) {
		return"Update Success";
	}else {
		return"Record didn't update";
	}
}
public String deleteProduct(int pid) {
	if(productDao.deleteProduct(pid)>0) {
		return"Deleted Successfully";
	}else {
		return"Record didn't delete";
	}
}
public String searchProductById(int pid) {
	Product p= productDao.searchProductById(pid);
	if(p==null) {
		return"Record not present";
	}else {
		return p.toString();
	}
}
public List<Product> getAllProducts(){
	return productDao.getAllProduct();
}
}
