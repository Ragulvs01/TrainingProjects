//alert("Welcome to Js")
function addData(){
   // alert("Event Fired.....")
   var name= document.getElementById("n1").value;
   var age=document.getElementById("n2").value;
   var ptag= document.createElement("p");
   var ptagcontent=document.createTextNode("Welcome "+name+"your age is"+age);
   ptag.appendChild(ptagcontent);
   document.getElementById("out").appendChild(ptag);
   if(age>30){
    ptag.setAttribute("class","myclass")
   }else{
    ptag.setAttribute("class","myclass1")
   }
   var atag=document.createElement("a")
   var atagcontent=document.createTextNode("remove");
   atag.appendChild(atagcontent)
   atag.setAttribute("href","#")
   atag.setAttribute("onclick", "deleteData()");
   ptag.appendChild(atag)
   document.getElementById("out").appendChild(ptag);
   document.getElementById("n1").value="";
   document.getElementById("n2").value="";
}
function deleteData(){
    alert("Event Fired.....")
}