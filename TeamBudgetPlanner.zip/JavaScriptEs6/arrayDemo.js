let num=[];
let num1=new Array();
let num2=[1,2,3,4]
document.write("Size of array is"+num.length)
document.write("<br/>Size of array is"+num1.length)
document.write("<br/>Size of array is"+num2.length)
document.write("<br/>All elements are is"+num2)
num2.push(50)
num2.push(60)
num2.unshift(12)
num2.unshift(13)
document.write("<br/>All Elements are"+num2)
num2.pop()
num2.shift()
document.write("<br/>All Elements are"+num2)
num2.splice(2,1)
document.write("<br/>The array is"+num2)
num2.splice(2,2)
document.write("<br/>The array is"+num2)
num2.splice(1,1,50)
document.write("<br/>The array is"+num2)
num2.splice(1,0,50)
document.write("<br/>The array is"+num2)
num2.splice(0,0,111,222,333)
document.write("<br/>The array is"+num2)
document.write("<br/>Basic for Loop")
for(let i=0;i<num2.length;i++){
    document.write("<br/>"+num2[i])
}
document.write("<br/>of Loop")
for(let obj of num2){
    document.write("<br/>"+obj)
}
document.write("<br/>in Loop")
for(let i in num2){
    document.write("<br/> The Index is"+i+" value is "+num2[i])
}
document.write("<br/>For each with callBack")
num2.forEach(display)
function display(n){
    document.write("<br/>"+n)
}
num2.forEach(function(n){
    document.write("<br/>"+n)
})
num2.forEach(n=>document.write("<br/>"+n))