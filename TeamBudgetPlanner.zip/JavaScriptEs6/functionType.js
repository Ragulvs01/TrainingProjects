function display1(){
    document.write("Normal Function")
}
display1();
let display3 = function display2(){
    document.write("<br/>Expression with function name")
}
display3();
let display4= function(){
    document.write("<br/>Expression without function name")
}
display4();
let display5=()=> document.write("<br/>Arrow Function")
display5()
let addNumber=(a,b)=>a+b;
document.write("<br/> Arrow function is "+addNumber(2,3))
function greeting(fname,callback){
    return"welcome "+callback(fname)
}
let maleInfo=function(fname){
    return"Mr."+fname;
}
let femaleInfo=(fname)=>"Miss."+fname;
document.write("<br/> "+greeting("raj",maleInfo))
document.write("<br/> "+greeting("Apu",femaleInfo))
document.write("<br/> "+greeting("ram",function(fname){
    return"Mr."+fname;
}))
document.write("<br/> "+greeting("Chandra",(fname)=>"Miss."+fname))
(function(){
    document.write("IIFE function")
})();

(function(){
    document.write("IIFe")
})();