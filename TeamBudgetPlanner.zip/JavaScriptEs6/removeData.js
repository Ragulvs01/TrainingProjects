function removeData(){
    sessionStorage.removeItem("obj1")
    localStorage.removeItem("obj2")
    //confirm("The data is removed")
    document.getElementById("out").innerHTML="Data Removed"
}