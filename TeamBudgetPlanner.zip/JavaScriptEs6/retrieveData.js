function retrieveData(){
    var obj1=sessionStorage.getItem("obj1")
    var obj2=localStorage.getItem("obj2")
    //alert("The Sessionstorage is "+obj1+" The Local Storage is "+obj2)
    document.getElementById("out").innerHTML="The Sessionstorage is "+obj1+" The Local Storage is "+obj2
}