function storeData(){
    var name="ram";
    sessionStorage.setItem("obj1",name)
    localStorage.setItem("obj2",name)
   // alert("data added")
   document.getElementById("out").innerHTML="Data added"
}