let emp1={id:100,name:"ram",age:24}
document.write("Literal Object Creation is")
document.write("<br/>The Id is"+emp1.id)
document.write("<br/>The name is"+emp1.name)
document.write("<br/>The age is"+emp1.age)
//Convert Object to String
let empString=JSON.stringify(emp1)
//convert String to JSON
let empJSON=JSON.parse(empString)
document.write("<br/>The Id is"+empJSON.id)
document.write("<br/>The name is"+empJSON.name)
document.write("<br/>The age is"+empJSON.age)
//convert JSON to String
let emp1String=JSON.stringify(empJSON)