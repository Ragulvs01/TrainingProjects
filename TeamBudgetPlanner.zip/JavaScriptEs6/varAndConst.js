var a=10;
a=20;
var a=30;
document.write(a);
let b=10;
b=20;
document.write(b);
for(var i=1;i<=1000;i++){

}
document.write(i);
for(let j=2;j<200;j++){

}
document.write(j);
const c=1000;
//c=2000;
document.write(c)