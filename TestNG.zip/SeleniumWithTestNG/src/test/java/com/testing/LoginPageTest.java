package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class LoginPageTest {
	WebDriver wd;
	@BeforeMethod
	  public void beforeMethod() {
		System.setProperty("webdriver.chrome.driver","D:\\Mphasis\\Learning Materials\\JavaPhase5\\program\\chromedriver_win32\\chromedriver.exe");
	    wd= new ChromeDriver();
	  }
  @Test
  public void LoginPageTest() {
	  wd.get("http://127.0.0.1:5500/login.html");
	  wd.manage().window().maximize();
	  WebElement emailref= wd.findElement(By.id("n1"));
	    emailref.sendKeys("ram@gmail.com");
	    WebElement passref= wd.findElement(By.id("n2"));
	    passref.sendKeys("123");
	    WebElement submitref= wd.findElement(By.id("b1"));
	    submitref.click();
	    Alert alertref= wd.switchTo().alert();
	    String result = alertref.getText();
	    alertref.accept();
	    assertEquals(result,"Login Success");
  }
  
  @AfterMethod
  public void afterMethod() {
	  wd.close();
  }

}
