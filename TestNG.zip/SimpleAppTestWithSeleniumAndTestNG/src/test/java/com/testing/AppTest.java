package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class AppTest {
	WebDriver wd;
  @Test
  public void f() {
	  wd.get("https://www.facebook.com/?stype=lo&jlou=AfevPhplLrHs0SmIravCtn3eE-Zy1jbZY4xPP8AccBQF2CQSbnoO3ezeTS61AUbabGJ-l99VC8MAciW8cxNh5Zn-m7OpPMl55VGZ2A4eryUlag&smuh=30914&lh=Ac_2FbjSbTt2Oxl6KF0");
	  wd.manage().window().maximize();
	  WebElement emailref= wd.findElement(By.id("email"));
	    emailref.sendKeys("ram@gmail.com");
	    WebElement passref= wd.findElement(By.id("pass"));
	    passref.sendKeys("123");
	    WebElement submitref= wd.findElement(By.name("login"));
	    submitref.click();
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver","D:\\Mphasis\\Learning Materials\\JavaPhase5\\program\\chromedriver_win32\\chromedriver.exe");
	    wd= new ChromeDriver();
  }

  @AfterMethod
  public void afterMethod() {
  }

}
