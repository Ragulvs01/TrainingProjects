package com.service;

import org.testng.annotations.Test;

public class BikeTest {
  @Test(groups = {"speed"})
  public void speed() {
	  System.out.println("Bike Speed is ");
  }
  @Test(groups= {"mileage","speed"})
  public void mileage() {
	  System.out.println("Bike Mileage is ");
  }
  @Test(groups= {"speed","price"})
  public void price() {
	  System.out.println("Bike price is ");
  }
}
